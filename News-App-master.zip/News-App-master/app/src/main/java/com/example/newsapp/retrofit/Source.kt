package com.example.newsapp.retrofit

data class Source(
    val id: Any,
    val name: String
)